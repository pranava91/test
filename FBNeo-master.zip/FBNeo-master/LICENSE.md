Please see the license [here](https://github.com/finalburnneo/FBNeo/blob/master/src/license.txt) for the full version
