   -[ atari devnotes ]-

  - good drivers -
badlands: good
shuuz: good.
skullxbo: good.
blastroid: good
thunderj: good.
xybots: good.
toobin: good
eprom: good. (sometimes scratchy/corrupted tms5220 voice synth noise?)
klax: good
atarig1: good
gauntlet: good
batman: good
vindictr: good
relief: good
arcadecl: good

  - WIP drivers -
offtwall
rampart

NOTE: _all_ games need good sync, see d_thunderj, d_blstroid's frame to see how it needs to be.

	- devices -
atarijsa: good
atarimo: good
atarivad: most likely good
atarirle: good
