void nb_1414m4_exec(UINT16 mcu_cmd,UINT16 *vram,UINT16 *scrollx,UINT16 *scrolly);

extern UINT8 *nb1414_blit_data;
extern UINT32 nb1414_frame;

