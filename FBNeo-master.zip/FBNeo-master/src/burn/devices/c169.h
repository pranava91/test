void c169_roz_init(UINT8 *ram, UINT8 *control, UINT16 *bitmap);
void c169_roz_draw(INT32 pri, INT32 line);
