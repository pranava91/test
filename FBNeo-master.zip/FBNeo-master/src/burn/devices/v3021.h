/* v3021 Calendar Emulation */

UINT8 v3021Read();
void v3021Write(UINT16 data);

void v3021Init();
void v3021Exit();

INT32 v3021Scan();
