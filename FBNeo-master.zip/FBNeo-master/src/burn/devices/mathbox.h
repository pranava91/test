void mathbox_reset();
void mathbox_scan(INT32 nAction, INT32 *);
void mathbox_go_write(UINT8 offset, UINT8 data);
UINT8 mathbox_status_read();
UINT8 mathbox_lo_read();
UINT8 mathbox_hi_read();
